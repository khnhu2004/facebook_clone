import "./closeFriend.css"

export default function CloseFriend() {
  return (
    <li className="sidebarFriend">
        <img className="sidebarFriendImg" src="asset/person/2.jpeg" alt="" />
        <span className="sidebarFriendName">Quách linh</span>
    </li>
  )
}
